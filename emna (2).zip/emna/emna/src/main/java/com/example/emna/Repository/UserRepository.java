package com.example.emna.Repository;


import com.example.emna.Entity.User;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    // You can define custom queries if necessary
}

