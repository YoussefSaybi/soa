package com.example.emna.Controller;

import java.util.List;
import java.util.Optional;

import com.example.emna.Entity.User;
import com.example.emna.Service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController // Changed to @RestController for REST API
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    // Show All Users
    @GetMapping
    public List<User> listUsers() {
        return userService.getAllUsers(); // Directly return the list of users
    }

    // Show a Specific User
    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable("id") Long id) {
        Optional<User> user = userService.getUserById(id);
        if (user.isPresent()) {
            return ResponseEntity.ok(user.get()); // Return 200 OK with the user data
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); // Return 404 if not found
        }
    }

    // Create a New User
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        User createdUser = userService.saveUser(user); // Save and return the newly created user
        return ResponseEntity.status(HttpStatus.CREATED).body(createdUser); // Return 201 Created status
    }

    // Update an Existing User
    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable("id") Long id, @RequestBody User user) {
        user.setId(id); // Ensure the user ID is set to update the correct record
        User updatedUser = userService.saveUser(user); // Save and return the updated user
        return ResponseEntity.ok(updatedUser); // Return 200 OK with the updated user
    }

    // Delete a User
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable("id") Long id) {
        userService.deleteUser(id); // Delete the user by ID
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build(); // Return 204 No Content after deletion
    }
}
