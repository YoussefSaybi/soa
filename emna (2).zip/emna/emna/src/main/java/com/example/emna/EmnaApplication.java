package com.example.emna;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmnaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmnaApplication.class, args);
	}

}
